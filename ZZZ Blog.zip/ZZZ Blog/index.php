<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>ZZZ Home Page</title>
  <style>
    body{
      margin:0;
      background-image: url('ASSETS/IMG/hq720.jpg');
      background-size: 100%;
    }
  </style>
</head>
<body>
    <?php include 'header.html' ?>
    <?php include 'footer.html' ?>
</body>
</html>
