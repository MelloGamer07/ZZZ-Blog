<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>EasyBike</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Grafica.css">
</head>
<body>

<!-- VIDEO BACKGROUND -->
<video autoplay muted loop>
    <source src="BackgroundMenu.mp4" type="video/mp4">
</video>

<div class="button">
    <p>Enter</p>
</div>

<div class="login">
    <div class="header-login">
        <p>HOYOVERSE</p>
    </div>
    <form class="body-login">
        <input class="input" type="input" placeholder="Enter username" name="Username" required>
        <input class="input" type="input" placeholder="Enter password" name="Password" required>
        <div class="Reg-Pas">
            <p class="R">Register now</p>
            <p>Forgot password?</p>
        </div>
    </form>
</div>
<!-- FOOTER -->
<footer class="footer">
    <h2>CONTATTI</h2>
    <p>
        <strong>Email</strong>: <a>ambrogio@easybike.com</a> |
        <strong>Tel</strong>: <a>+39 6868686420</a> |
        <strong>Stazione Principale</strong>: <a>Via Borzoli 21, 16153 Genova</a>
    </p>
</footer>

<script>
    document.querySelector('.menuLogo').onclick = () => {
        const menu = document.querySelector('.menuList');
        menu.style.display = menu.style.display === "flex" ? "none" : "flex";
    };
    document.querySelector('.logo').onclick = () => {
        window.location.href = "Home.php";
    };
</script>
</body>
</html>